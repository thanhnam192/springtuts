let sportsOne: string[] = ["Golf", "Cricket", "Tennis", "Swimming"];

for (let tempSport of sportsOne) {

    if (tempSport == "Cricket") {
        console.log(tempSport  + " << My Favorite!");
    }
    else {
        console.log(tempSport);
    }
}